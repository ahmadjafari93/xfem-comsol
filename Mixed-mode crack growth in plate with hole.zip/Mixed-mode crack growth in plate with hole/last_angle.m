function [alpha] = last_angle(x)

% This function calls the angle of last crack segment that was previously
% saved as MAT file.

%%%% inputs (address and file names):
path              = fileparts(which('last_angle.m'));

load (fullfile(path,'crackpt.mat'),'crackpt');
xtip = crackpt(:,1)';
ytip = crackpt(:,2)';
dx   = xtip(end)-xtip(end-1);
dy   = ytip(end)-ytip(end-1);
r    = sqrt((ytip(end)-ytip(end-1))^2+(xtip(end)-xtip(end-1))^2);
alpha1 = asin(dy./r);
alpha2 = acos(dx./r);

if alpha1>0
    alpha= alpha2;
else
    alpha= -alpha2;
end