function out=interpol(x,y)

%This functions interpolates the enrichment condition of any point of
% interest based on the previously stored interpolate.MAT file, and return
% a value between 0 and 1.
% if the returned value is 1, this means that the point is located inside
% the enrichment zone.


%%%% inputs (address and file names):
path  = fileparts(which('interpol.m'));

load (fullfile(path,'interpolate.mat'),'interpolate');
col1 = interpolate(:,1);
col2 = interpolate(:,2);
col3 = interpolate(:,3);
F = scatteredInterpolant(col1,col2,col3);
out=F(x,y);
end

