function [out] = update_crack (K1,K2,K1C,dL)

% In this function, the crack is updated according to the imported stress
% intensity factors and material toughness (K1, K2, K1C). If propagation
% occurs, the whole preprocessing is repeated for the update configuration.


%%%% inputs:
path  = fileparts(which('update_crack.m'));

load (fullfile(path,'crackpt.mat'),'crackpt');
load (fullfile(path,'delta.mat'),'delta');
load (fullfile(path,'node.mat'),'node')
load (fullfile(path,'element.mat'),'element')
elemnodes = 4; % quarilateral element

xtip = crackpt(:,1)';
ytip = crackpt(:,2)';
dx   = xtip(end)-xtip(end-1);
dy   = ytip(end)-ytip(end-1);
r    = sqrt((ytip(end)-ytip(end-1))^2+(xtip(end)-xtip(end-1))^2);
alpha1 = asin(dy./r);
alpha2 = acos(dx./r);
if alpha1>0
    alpha= alpha2;
else
    alpha= -alpha2;
end

% crack propagation angle THETA (in local crack coordinate system)
if K2>0
    THETA = -acos((3*K2^2+sqrt(K1^4+8*K1^2*K2^2))/(K1^2+9*K2^2)) ;
else
    THETA =  acos((3*K2^2+sqrt(K1^4+8*K1^2*K2^2))/(K1^2+9*K2^2));
end

% Equivalent SIF to initiate the crack propagation
Keq = K1*(cos(THETA/2))^3-1.5*K2*cos(THETA/2)*sin(THETA);

if Keq>K1C
    alpha = THETA + alpha; % convert crack angle from local to global coordinate system
    new_xtip = xtip(end)+dL*cos(alpha); % dL is the predefined crack increment.
    new_ytip = ytip(end)+dL*sin(alpha);
    crackpt = [crackpt;new_xtip new_ytip];% t];
    save (fullfile(path,'crackpt.mat'),'crackpt');
    
    xtip   = crackpt(:,1)';
    ytip   = crackpt(:,2)';
    nseg   = length(xtip)-1;
    nnode  = length(node);
    nelem  = length(element);
    enrich_phi = zeros(nnode,1);
    enrich = zeros(nelem,1);
    
    for ielem = 1:nelem % loop over elements
        corner = [element(ielem,:) element(ielem,1)];
        inode = node(element(ielem,:),:);
        num_intersect = zeros(1,2);
        count   = 0;
        for jnode = 1:elemnodes  % loop over nodes of an element
            x1  = [node(corner(jnode),1) node(corner(jnode+1),1)];
            y1  = [node(corner(jnode),2) node(corner(jnode+1),2)];
            x2 = [xtip(nseg) xtip(nseg+1)];
            y2 = [ytip(nseg) ytip(nseg+1)];
            [x_intersect,y_intersect] = polyxpoly(x1,y1,x2,y2);
            if ~isempty(x_intersect)
                intersection(nseg,:) = [x_intersect,y_intersect];
                count = count+1;
                num_intersect(count) = jnode;
                inode = [inode;intersection(nseg,:)];
                d1 = sqrt((x_intersect-x1(1))^2+(y_intersect-y1(1))^2);
                d2 = sqrt((x_intersect-x1(2))^2+(y_intersect-y1(2))^2);
                side_length = sqrt((x1(1)-x1(2))^2+(y1(1)-y1(2))^2);
                cut_ratio = min(d1,d2)/side_length;
                count1 = num_intersect(1);
                count2 = num_intersect(2);
                icond = ((count1==1 && count2==3) ||  (count1==2 && count2==4));
                if cut_ratio> delta || icond
                    enrich(ielem)=1;
                end
            end
        end
    end
    
    enrich_elem = find(enrich==1);
    enrich_node = unique(element(enrich_elem,:));
    
    enrich_phi (enrich_node,1) = 1;
    
    load (fullfile(path,'interpolate.mat'),'interpolate');
    old_enrich_phi = interpolate(:,3);
    new_enrich_phi = old_enrich_phi | enrich_phi;
    new_enrich_phi = double (new_enrich_phi);
    
    % saving the vector of enrichment status of the entire nodes along with their
    % corresponding nodal coordinates, ans store as MAT file.
    % interpolate = [x(i) y(i) (0 or 1)]
    interpolate = [node new_enrich_phi];
    save (fullfile(path,'interpolate.mat'),'interpolate');
end
out = Keq;
