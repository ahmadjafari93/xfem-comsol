clear all
close all
clc
tic;
disp('                                                                   ')
disp('*******************************************************************')
disp('****                                                           ****')
disp('****        XFEM implmentation in COMSOL Multiphysics          ****')
disp('                                                                   ')
disp('****      School of Civil and Environmental Engineering        ****')
disp('****               University of New South Wales               ****')
disp('                                                                   ')
disp('****                Compiled by A. Jafari                      ****')
disp('                                                                   ')
disp('****          Collaborators: M. Vahab, P. Broumand             ****')
disp('****            Supervised by Prof. N. Khalili                 ****')
disp('*******************************************************************')


% This is the preprocessing function. In here, all input are inserted, aiming 
% to determine the initial enrichment configuration (enriched nodes
% and elements). In addition, key parameters such as nodal
% coordinates, element connectivity, cracks coordinates, average element 
% size and minimum support of nodes (for numerical integration purposes)
% are also stored as MAT-files in order to be used in other function during
% COMSOL analysis.  

path    = fileparts(which('preprocess.m'));

%%%% inputs:
% Crack inputs: total number & initial coordiantes
% also stored as MAT files
crackpt = [-0.01	0.0675;
            0.010	0.0675];

save (fullfile(path,'crackpt.mat'),'crackpt');
xtip = crackpt(:,1)';
ytip = crackpt(:,2)';
nseg = length(xtip)-1; % number of segments for each crack. For strait cracks, nseg = 1


% Average element size parameter:
% The normal distance from the crack from which the Heaviside values
% are calculated. it is recommended to take this value about twice the average
% element size at the crack zone.
epss = 0.0025;
save (fullfile(path,'epss.mat'),'epss');

% Minimum nodal support parameter:
% This is introduced to avoid singularities due to small support of a node
% (e.g. crack passing very close to a node). It is introduced as the
% minimum acceptable ratio of shortest distance between the intersection
% point of the crack and element edges with respect to the average element
% size.
% for example, delta = 0.05 means that if a crack intersect an element edge
% with the distance of less than 0.05*average element size, the
% corresponding element will not be enriched.
delta = 0.01;  
save (fullfile(path,'delta.mat'),'delta');


% import mesh file 
input_mesh    = 'mesh.mphtxt';
input         = fileread(input_mesh);
%-------------------------------------------------------------------------

% Reading mesh detail:
% Here, the input mesh file ".mphtxt" is read, reshaped and sorted in order
% to store the nodal points and element connectivity as MAT files.
% nodes:
input_node = regexprep(input, '.*# Mesh vertex coordinates\s*','');
data1 = sscanf(input_node, '%f');
data1(end)=[];
nodecol1 = 1:2:size(data1,1);
nodecol2 = 2:2:size(data1,1);
node  = [data1(nodecol1),data1(nodecol2)];
nnode = length(node);
save (fullfile(path,'node.mat'),'node');

% elements:
input_elem = regexprep(input, '.*# Elements\s*','');
data2 = sscanf(input_elem, '%f');
data2(end)=[];
elemnodes = 4;
if elemnodes==4
    elemcol1 = 1:4:size(data2,1);
    elemcol2 = 2:4:size(data2,1);
    elemcol3 = 3:4:size(data2,1);
    elemcol4 = 4:4:size(data2,1);
    element = [data2(elemcol1),data2(elemcol2),data2(elemcol3),data2(elemcol4)]+1;
    a = element (:,3);
    element (:,3) = element (:,4);
    element (:,4) = a;
    clear a
else
    elemcol1 = 1:3:size(data2,1);
    elemcol2 = 2:3:size(data2,1);
    elemcol3 = 3:3:size(data2,1);
    element = [data2(elemcol1),data2(elemcol2),data2(elemcol3)]+1;
end
nelem = length(element);
save (fullfile(path,'element.mat'),'element');

% enrich_phi = a binary vector of enrichment condition of all nodes 
%( if == 1 enriched, if == 0 unenriched)
enrich_phi = zeros(nnode,1);

% enrich = a binary vector of enrichment condition of all elements 
%( if == 1 enriched, if == 0 unenriched)
enrich     = zeros(nelem,1);

% geometrical search of all crack(s) over the entire geometry
for ielem = 1:nelem % loop over number of elements
    corner = [element(ielem,:) element(ielem,1)];
    inode = node(element(ielem,:),:);
    a_total = polyarea(inode(:,1),inode(:,2));
    num_intersect = zeros(1,2);
    for jnode = 1:elemnodes % loop over the nodes of an element
        x1  = [node(corner(jnode),1) node(corner(jnode+1),1)];
        y1  = [node(corner(jnode),2) node(corner(jnode+1),2)];
        count   = 0;
        for jseg = 1:nseg % For multi-segment (curved) cracks. In strait cracks, no loop needed.
            x2 = [xtip(jseg) xtip(jseg+1)];
            y2 = [ytip(jseg) ytip(jseg+1)];
            [x_intersect,y_intersect] = polyxpoly(x1,y1,x2,y2);
            if ~isempty(x_intersect)
                count = count+1;
                num_intersect(count) = jnode;
                d1 = sqrt((x_intersect-x1(1))^2+(y_intersect-y1(1))^2);
                d2 = sqrt((x_intersect-x1(2))^2+(y_intersect-y1(2))^2);
                side_length = sqrt((x1(1)-x1(2))^2+(y1(1)-y1(2))^2);
                cut_ratio = min(d1,d2)/side_length;
                count1 = num_intersect(1);
                count2 = num_intersect(2);
                icond = ((count1==1 && count2==3) ||  (count1==2 && count2==4));
                if cut_ratio>delta || icond
                    enrich(ielem)=1;
                end
            end
        end
    end
end

% saving enriched nodes and elements:
enrich_elem = find(enrich==1);
enrich_node = unique(element(enrich_elem,:));
enrich_phi (enrich_node,1) = 1;

% saving the vector of enrichment status of the entire nodes along with their
% corresponding nodal coordinates, ans store as MAT file.
% interpolate = [x(i) y(i) (0 or 1)]
interpolate = [node enrich_phi];
save (fullfile(path,'interpolate.mat'),'interpolate');

clear all
%--------------------------------------------------------------------------
disp(' ')
disp('*******************************************************************')
disp(['   End of Preprocessing                        ',num2str(toc),'sec'])
disp('*******************************************************************')
disp(' ')