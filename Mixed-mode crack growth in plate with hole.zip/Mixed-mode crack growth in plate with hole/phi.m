function [crT] = phi(x,y)

% This function evaluates the value of Heaviside function for points of
% interest (e.g., Guass points) within normal distance of 'epss' from the
% crack. 
% crT vector is = 1 for points in +epss zone
%               = -1 for points in -epss zone
%               = 0 other points (out of the enrichment zone)

%%%% inputs:
path                 = fileparts(which('phi.m'));

load (fullfile(path,'epss.mat'),'epss');
load (fullfile(path,'crackpt.mat'),'crackpt');
xtip = crackpt(:,1)';
ytip = crackpt(:,2)';

crT  = zeros (size(x));
crT  = reshape(crT,[1,length(crT)]);

x = reshape(x,[1,length(x)]);
y = reshape(y,[1,length(y)]);

[d,is_in_seg,xc,yc]  = p_poly_dist(x, y, xtip, ytip);
d                    = reshape(d,[1,length(d)]);

% is_in_seg    = is_in_seg(:,end)';
% xc           = xc(:,end)';
% yc           = yc(:,end)';
% distx1        = xc-xtip(end);
% disty1        = yc-ytip(end);
% distx2        = xc-xtip(end-1);
% disty2        = yc-ytip(end-1);
% dist1         = sqrt(distx1.^2+disty1.^2);
% dist2         = sqrt(distx2.^2+disty2.^2);

q1      = [xtip(1),ytip(1)];
q2      = [xtip(end),ytip(end)];
pt_far1 = q1 - 100*(q2-q1);
pt_far2 = q2 + 100*(q2-q1);
crack_normal = cross([0 0 1],[(q2-q1) 0])/norm(cross([0 0 1],[(q2-q1) 0]));
pt_far_out   = q1 + 1000 *crack_normal(1:2);

xv = [pt_far1(1),xtip,pt_far2(1),pt_far_out(1)];
yv = [pt_far1(2),ytip,pt_far2(2),pt_far_out(2)];

%*****************************************
q11      = [xtip(end-1),ytip(end-1)];
qcrack  = (q2-q11)./norm(q2-q11);
qnorm = cross([0 0 1],[(q2-q11) 0])/norm(cross([0 0 1],[(q2-q11) 0]));
q21   = q2+2*epss*qnorm(1:2);
q22   = q2-2*epss*qnorm(1:2);

q21p  = q21+2*qcrack*epss;
q22p  = q22+2*qcrack*epss;

xvtip    = [q21(1),q21p(1),q22p(1),q22(1)];
yvtip    = [q21(2),q21p(2),q22p(2),q22(2)];

outtip1   = ~inpolygon(x,y,xvtip,yvtip);

%*****************************************
q11      = [xtip(end-1),ytip(end-1)];
qcrack  = -(q2-q11)./norm(q2-q11);
qnorm = cross([0 0 1],[-(q2-q11) 0])/norm(cross([0 0 1],[-(q2-q11) 0]));
q01   = q11+2*epss*qnorm(1:2);
q02   = q11-2*epss*qnorm(1:2);

q01p  = q01+2*qcrack*epss;
q02p  = q02+2*qcrack*epss;

xvtip1    = [q01(1),q01p(1),q02p(1),q02(1)];
yvtip1    = [q01(2),q01p(2),q02p(2),q02(2)];

outtip2   = ~inpolygon(x,y,xvtip1,yvtip1);

crtplus  = inpolygon(x,y,xv,yv)  & d<=epss & outtip1;% & outtip2;%  &  ( is_in_seg | (~is_in_seg & ~neartip)) ;
crtminus = ~inpolygon(x,y,xv,yv) & d<=epss & outtip1;% & outtip2;%  &  ( is_in_seg | (~is_in_seg & ~neartip)) ;

crT(crtplus) =  1;
crT(crtminus)= -1;