function [new_tip] = read_crack (x)

% This function calls the updated crack tip coordinates that was previously
% saved as MAT file.

%%%% inputs:
path   = fileparts(which('read_crack.m'));

load (fullfile(path,'crackpt.mat'),'crackpt');
xtip = crackpt(:,1)';
ytip = crackpt(:,2)';
new_xtip = xtip(end);
new_ytip = ytip(end);
new_tip = new_xtip+1i*new_ytip;

end